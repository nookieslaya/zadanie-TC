@extends('layouts.app')

@section('content')
  {!! $content !!}
@endsection
